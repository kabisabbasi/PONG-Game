#include <raylib.h>
#include <string>
using namespace std;

/////// Game loop consists of ///////
// events
// update data based on events
// display data

////// Draw Circle takes x,y co-oridinates [center of circle], radius, and color constructor

int player_score = 0;
int cpu_score = 0;

Color Green = Color{ 38,185,154,255 };
Color Dark_Green = Color{ 20,160,133,255 };
Color Light_Green = Color{ 129,204,154,255 };
Color Yellow = Color{ 38,185,154,255 };


class Ball {
public:
	float x, y;
	int speed_x, speed_y;
	int radius;

	//white circle in center of window
	void Draw() {
		DrawCircle(x, y, radius, YELLOW);
	}

	void Update() {
		x += speed_x;
		y += speed_y;

		if (y + radius >= GetScreenHeight() || y - radius <= 0) {
			speed_y *= -1;
		}

		if (x + radius >= GetScreenWidth()) {
			cpu_score++;
			speed_x *= -1;
		
		} 
		if( x - radius <= 0) {
			speed_x *= -1;
			player_score++;
		}
	}
};

class Paddle {

protected:
	void LimitMovement() {

		if (y >= GetScreenHeight() - height) {
			y = y - speed;
		}
		if (y <= 0) {
			y = y + speed;
		}
	}

public:

	float x, y;
	float width, height;
	int speed;

	void Draw(){
	
		DrawRectangle(x, y, 25, 120, WHITE);

	}

	void Update() {
		
		if (IsKeyDown(KEY_UP)) {
			y = y - speed;
		}

		if (IsKeyDown(KEY_DOWN)) {
			y = y + speed;
		}

		LimitMovement();

	}

};

class CpuPaddle : public Paddle{
public:
	void Update(int ball_y) {
		if (y + height / 2 > ball_y) {
			y = y - speed;
		}

		if (y + height / 2 < ball_y) {
			y = y + speed;
		}

		LimitMovement();
	}
};

Ball ball;
Paddle player;
CpuPaddle cpu;

int main() {
		
		//screen height and width
		const int screen_width = 1280;
		const int screen_height = 800;
		InitWindow(screen_width, screen_height, "My pong game");

		//player paddle initialization

		player.width = 25;
		player.height = 125;
		player.speed = 6;
		player.x = screen_width - player.width - 10;
		player.y = screen_height / 2 - player.height / 2;

		//cpu paddle initialization

		cpu.width = 25;
		cpu.height = 125;
		cpu.speed = 6;
		cpu.x = 10;
		cpu.y = screen_height / 2 - cpu.height / 2;

		//ball object initialization
		ball.radius = 20;
		ball.x = screen_width / 2;
		ball.y = screen_height / 2;
		ball.speed_x = 7;
		ball.speed_y = 7;

		
		SetTargetFPS(60); // how fast the game should run
		while (WindowShouldClose() == false) {	//while return of Window Should Close value is false

		BeginDrawing(); //creates canvas

		///// DRAWINGS /////
		ClearBackground(Dark_Green);
		DrawRectangle(screen_width / 2, 0, screen_width / 2, screen_height, Green);
		DrawLine(screen_width / 2, 0, screen_width / 2, 800, WHITE);

		//ball
		ball.Update();
		ball.Draw();

		//check for collisions
		if (CheckCollisionCircleRec(Vector2{ ball.x,ball.y },ball.radius,Rectangle{player.x,player.y,player.width,player.height})) {
			ball.speed_x *= -1;
		}
		if (CheckCollisionCircleRec(Vector2{ ball.x,ball.y }, ball.radius, Rectangle{ cpu.x,cpu.y,cpu.width,cpu.height })) {
			ball.speed_x *= -1;
		}

		//paddle
		player.Update();
		player.Draw();

		//cpu paddle
		cpu.Update(ball.y);
		cpu.Draw();

		DrawText(TextFormat("%i",cpu_score),screen_width/4-20,20,80,WHITE); //%i means the function is to expect an integer and convert it to a char pointer
		DrawText(TextFormat("%i", player_score), 3*screen_width / 4 - 20, 20, 80, WHITE);
		EndDrawing(); //closes canvas

		}

		CloseWindow();
		return 0;
	}
						